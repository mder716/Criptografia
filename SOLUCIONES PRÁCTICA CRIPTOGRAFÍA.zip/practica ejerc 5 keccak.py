import hashlib


# initiating the "s" object to use the sha512 del ejercicio
s = hashlib.sha512()
s.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía","UTF-8"))
print("sha_512 "+s.digest().hex())
#sha3-256 keccak sin punto
s = hashlib.sha3_256()
s.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía","UTF-8"))
print("sha3_256 "+s.digest().hex())

s= hashlib.sha3_256()
s.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía.", "utf8"))
print("SHA3-256: " + s.digest().hex())

