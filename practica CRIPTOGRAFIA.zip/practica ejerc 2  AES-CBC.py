
   
import json
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

#Cifrado
textoPlano_bytes = bytes('Felipe, me molan mogollón tus clases, son una pasada', 'UTF-8')
#Se puede generar aleatoriamente una clave de 16 bytes.
#clave = get_random_bytes(16)
clave = bytes.fromhex('A2CFF885901A5449E9C448BA5B948A8C4EE377152B3F1ACFA0148FB3A426DB72') #clave en hex sacada del programa Key Store Explorer

iv_bytes = bytes.fromhex('00000000000000000000000000000000')
cipher = AES.new(clave, AES.MODE_CBC,iv_bytes)
texto_cifrado_bytes = cipher.encrypt(pad(textoPlano_bytes, AES.block_size,  style='pkcs7'))
#Si se generase de forma automática, por no especificarlo en la llamada, se recuperaría así.
iv_b64 = b64encode(cipher.iv).decode('utf-8')
texto_cifrado_b64 = b64encode(texto_cifrado_bytes).decode('utf-8')

#Esto no es cripto, simplemente almacenamos la informacion "elegantemente"
mensaje_json = json.dumps({'iv':iv_b64, 'texto cifrado':texto_cifrado_b64, 'texto cifrado hex':texto_cifrado_bytes.hex()})
#print(mensaje_json)

#Descifrado

try:
    b64 = json.loads(mensaje_json)
    iv_desc_bytes = b64decode(b64['iv'])
    textoPlano_bytes = bytes('Felipe, me molan mogollón tus clases, son una pasada', 'UTF-8')
    texto_cifrado_bytes = b64decode('NDY2NTZjNjk3MDY1MmMyMDZkNjUyMDZkNmY2YzYxNmUyMDZkNmY2NzZmNmM2Y2YzNmUyMDc0NzU3MzIwNjM2YzYxNzM2NTczMmMyMDczNmY2ZTIwNzU2ZTYxMjA3MDYxNzM2MTY0NjE=')
    cipher = AES.new(clave, AES.MODE_CBC, iv_desc_bytes)
    mensaje_des_bytes = unpad(cipher.decrypt(texto_cifrado_bytes), AES.block_size, style="x923")
    #mensaje_des_bytes = cipher.decrypt(textoPlano_bytes)
    print(mensaje_des_bytes.hex())
    print(b64encode(mensaje_des_bytes).decode('utf-8'))
    print("El texto en claro es: ", mensaje_des_bytes.decode("utf-8"))

except (ValueError, KeyError) as error:
    print('Problemas para descifrar....')
    print("El motivo del error es: ", error) 