import hashlib


# initiating the "s" object to use the
# sha3_256 algorithm from the hashlib module.
s = hashlib.sha256()
s = hashlib.sha3_256()

# will output the name of the hashing algorithm currently in use.
print(s.name)

# will output the Digest-Size of the hashing algorithm being used.
print(s.digest_size)

# providing the input to the hashing algorithm.
#s.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía","UTF-8"))
s.update(bytes.fromhex("4cec5a9f85dcc5c4c6ccb603d124cf1cdc6dfe836459551a1044f4f2908aa5d63739506f6468833d77c07cfd69c488823b8d858283f1d05877120e8c5351c833"))
s.update(bytes("En KeepCoding aprendemos cómo protegernos con criptografía.","UTF-8"))
print(s.hexdigest())
