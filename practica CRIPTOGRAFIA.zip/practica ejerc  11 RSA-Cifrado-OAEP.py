from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256


# Generamos un par de claves, de longitud 2048 bits.
keyPair = RSA.generate(2048)

#Generamos la pública
pubKey = keyPair.publickey()
pubKeyPEM = pubKey.export_key()
print(pubKeyPEM.decode('utf8'))
print("--------------------------------------------------")

#Generamos la privada
privKeyPEM = keyPair.exportKey()
print(privKeyPEM.decode('utf8'))

mensaje = bytes.fromhex("e2cff885901a5449e9c448ba5b948a8c4ee377152b3f1acfa0148fb3a426db72")

encryptor = PKCS1_OAEP.new(pubKey,SHA256)
encrypted = encryptor.encrypt(mensaje)

print("Cifrado:", encrypted.hex())
print("--------------------------------------------------")